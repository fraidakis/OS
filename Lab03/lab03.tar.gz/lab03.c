#include "lab03.h"

int main() {
    print_message();
    return 0;
}
